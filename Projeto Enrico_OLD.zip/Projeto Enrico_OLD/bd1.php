<?php

require_once('conexao1.php');

$email = $_POST['email'];
$nome = $_POST['nome'];
$sobrenome = $_POST['sobrenome'];
$mensagem = $_POST['mensagem'];

$sql = "INSERT INTO voucher (email, nome, sobrenome, mensagem) VALUES ('$email', '$nome', '$sobrenome', '$mensagem')";
$result = $mysqli->query($sql);


?>